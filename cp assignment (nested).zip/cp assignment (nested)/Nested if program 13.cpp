#include <iostream>
using namespace std;

int main() {
    int age;
    cout << "Enter age: ";
    cin >> age;

    if (age > 0) {
        if (age >= 18) {
            cout << "Eligible for a driving license." << endl;
        } else {
            cout << "Not eligible for a driving license (must be 18 or older)." << endl;
        }
    } else {
        cout << "Invalid age entered." << endl;
    }

    return 0;
}
