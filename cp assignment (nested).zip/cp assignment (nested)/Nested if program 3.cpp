#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;

    if (num >= 0) {
        if (num > 10) {
            cout << "The number is greater than 10." << endl;
        } else {
            cout << "The number is 10 or less." << endl;
        }
    } else {
        cout << "The number is negative, so it is not greater than 10." << endl;
    }

    return 0;
}
