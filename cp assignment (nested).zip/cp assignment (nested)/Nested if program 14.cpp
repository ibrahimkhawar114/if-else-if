#include <iostream>
using namespace std;

int main() {
    double price;
    cout << "Enter product price: ";
    cin >> price;

    if (price >= 0) {
        if (price > 5000.0) {
            cout << "Product price is above 5000." << endl;
        } else {
            cout << "Product price is 5000 or below." << endl;
        }
    } else {
        cout << "Invalid price entered." << endl;
    }

    return 0;
}
