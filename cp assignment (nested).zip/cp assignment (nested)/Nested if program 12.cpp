#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;

    if (num >= 0) {
        if (num > 50) {
            cout << "The number is greater than 50." << endl;
        } else {
            cout << "The number is 50 or less." << endl;
        }
    } else {
        cout << "The number is negative, so it is not greater than 50." << endl;
    }

    return 0;
}
