#include <iostream>
using namespace std;

int main() {
    float temp;
    cout << "Enter temperature in Celsius: ";
    cin >> temp;

    if (temp > -273.15) { 
        if (temp > 30.0) {
            cout << "Temperature is above 30 degrees C." << endl;
        } else {
            cout << "Temperature is 30 degrees C or below." << endl;
        }
    } else {
        cout << "Temperature below absolute zero is not physically possible." << endl;
    }

    return 0;
}
