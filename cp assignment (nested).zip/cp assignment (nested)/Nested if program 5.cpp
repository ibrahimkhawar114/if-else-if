#include <iostream>
using namespace std;

int main() {
    int marks;
    cout << "Enter marks (0-100): ";
    cin >> marks;

    if (marks >= 0 && marks <= 100) {
        if (marks >= 40) {
            cout << "Student has PASSED." << endl;
        } else {
            cout << "Student has FAILED." << endl;
        }
    } else {
        cout << "Invalid marks entered." << endl;
    }

    return 0;
}
