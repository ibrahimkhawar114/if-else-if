#include <iostream>
using namespace std;

int main() {
    int marks;
    cout << "Enter student marks (0-100): ";
    cin >> marks;

    if (marks >= 0 && marks <= 100) {
        if (marks > 80) {
            cout << "Marks are above 80." << endl;
        } else {
            cout << "Marks are 80 or below." << endl;
        }
    } else {
        cout << "Invalid marks entered." << endl;
    }

    return 0;
}
