#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;

    if (num % 2 == 0) { // First check if even
        if (num % 10 == 0) {
            cout << "The number is divisible by 10." << endl;
        } else {
            cout << "The number is even, but not divisible by 10." << endl;
        }
    } else {
        cout << "The number is odd, so it is not divisible by 10." << endl;
    }

    return 0;
}
