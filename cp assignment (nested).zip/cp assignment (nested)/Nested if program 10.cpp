#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;

    if (num >= 0) {
        if (num == 100) {
            cout << "The number is equal to 100." << endl;
        } else {
            cout << "The number is not equal to 100." << endl;
        }
    } else {
        cout << "The number is negative, so it cannot equal 100." << endl;
    }

    return 0;
}
