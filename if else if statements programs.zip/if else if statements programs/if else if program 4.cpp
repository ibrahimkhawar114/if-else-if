#include <iostream>
using namespace std;
int main()
{
	int age;
	cout <<"Enter the age:";
	cin >>age;
	if (age >=18){
	cout <<"You can vote." <<endl;
}
	else if(age <=18){
	cout <<"you cannot vote." <<endl;
}
    else{
    cout <<"Invalid age is entered." <<endl;
}   
return 0;	
}
