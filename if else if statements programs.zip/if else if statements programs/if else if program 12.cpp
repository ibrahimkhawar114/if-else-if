#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;

    if (num > 50) {
        cout << "The number is greater than 50." << endl;
    } else if (num < 50) {
        cout << "The number is less than 50." << endl;
    } else {
        cout << "The number is equal to 50." << endl;
    }

    return 0;
}

