#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;

    if (num == 100) {
        cout << "The number is equal to 100." << endl;
    } else if (num > 100) {
        cout << "The number is greater than 100." << endl;
    } else {
        cout << "The number is less than 100." << endl;
    }

    return 0;
}
