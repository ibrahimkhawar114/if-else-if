#include <iostream>
using namespace std;
int main ()
{
	int num;
	cout <<"Enter a number: ";
	cin >>num;
	if (num <0)
	cout <<"The number is Negative." <<endl;
	else if (num >0)
	cout <<"The number is Positive." <<endl;
	else 
	cout <<"The number is zero." <<endl;
	return 0;
	
}
