#include <iostream>
using namespace std;

int main() {
    float temp;
    cout << "Enter temperature in �C: ";
    cin >> temp;

    if (temp > 30.0) {
        cout << "Temperature is above 30�C." << endl;
    } else if (temp < 30.0) {
        cout << "Temperature is below 30�C." << endl;
    } else {
        cout << "Temperature is exactly 30�C." << endl;
    }

    return 0;
}
