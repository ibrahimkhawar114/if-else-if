#include <iostream>
using namespace std;

int main() {
    int marks;
    cout << "Enter marks: ";
    cin >> marks;

    if (marks > 80) {
        cout << "Marks are above 80." << endl;
    } else if (marks <= 80 && marks >= 0) {
        cout << "Marks are 80 or below." << endl;
    } else {
        cout << "Invalid marks entered." << endl;
    }

    return 0;
}
