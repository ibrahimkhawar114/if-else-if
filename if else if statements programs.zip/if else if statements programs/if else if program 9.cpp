#include <iostream>
using namespace std;

int main() {
    int age;
    cout << "Enter age: ";
    cin >> age;

    if (age > 60) {
        cout << "Age is above 60 (Senior Citizen)." << endl;
    } else if (age < 60) {
        cout << "Age is 60 or below." << endl;
    } else {
        cout << "Age is exactly 60." << endl;
    }

    return 0;
}
