#include <iostream>
using namespace std;
int main()
{
	int marks;
	cout <<"Enter the marks:";
	cin >>marks;
	if (marks >=40){
		cout <<"The student is passed." <<endl;
	}
	else if(marks <=40){
		cout <<"The student is failed." <<endl;
	}
	else{
		cout <<"Invalid marks entered." <<endl;
	}
	return 0;
}
