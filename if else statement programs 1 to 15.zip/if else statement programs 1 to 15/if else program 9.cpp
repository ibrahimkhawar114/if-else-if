#include <iostream>
using namespace std;

int main()
{
    int num;
    cout << "Enter a number: ";
    cin >> num;

    if (num == 100)
        cout << "Number is equal to 100";
    else
        cout << "Number is not equal to 100";

    return 0;
}
