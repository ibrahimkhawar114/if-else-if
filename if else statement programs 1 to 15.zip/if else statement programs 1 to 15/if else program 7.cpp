#include <iostream>
using namespace std;
int main()
{
	int temperature;
	cout <<"Enter the temperature: ";
	cin >>temperature;
	if (temperature >30)
	cout <<"The temperature is above 30: ";
	else 
	cout <<"The temperature is 30 or below: ";
	return 0;
	
}
