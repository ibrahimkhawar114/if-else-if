#include <iostream>
using namespace std;

int main()
{
    int num;
    cout << "Enter a number: ";
    cin >> num;

    if (num > 50)
        cout << "Greater than 50";
    else
        cout << "Not greater than 50";

    return 0;
}
