#include <iostream>
using namespace std;
int main()
{
	int marks;
	cout <<"Enter the marks: ";
	cin >> marks;
	if (marks >=40)
	cout <<"The student is passed: ";
	else
	cout <<"The student is fail: ";
	return 0;
	
}

