#include <iostream>
using namespace std;

int main()
{
    int price;
    cout << "Enter product price: ";
    cin >> price;

    if (price > 500)
        cout << "Price is above 500";
    else
        cout << "Price is 500 or below";

    return 0;
}
