#include <iostream>
using namespace std;

int main()
{
    int marks;
    cout << "Enter marks: ";
    cin >> marks;

    if (marks > 80)
        cout << "Marks are above 80";
    else
        cout << "Marks are 80 or below";

    return 0;
}
